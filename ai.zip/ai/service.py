def calculate_discount(customer_type: str, order_amount: float) -> float:
    if customer_type == "Regular" and order_amount >= 1000:
        return order_amount * 0.1
    elif customer_type == "Premium":
        return order_amount * 0.15
    else:
        return 0.0
