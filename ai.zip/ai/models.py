from pydantic import BaseModel

class DiscountRequest(BaseModel):
    customer_type: str
    order_amount: float

class DiscountResponse(BaseModel):
    discount: float
