from fastapi import FastAPI
from models import DiscountRequest, DiscountResponse
from service import calculate_discount

app = FastAPI()

@app.post("/calculate-discount", response_model=DiscountResponse)
def get_discount(data: DiscountRequest):
    discount = calculate_discount(data.customer_type, data.order_amount)
    return DiscountResponse(discount=discount)
